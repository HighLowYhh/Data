'''
这是GUI界面下的"田"字型框架演示程序，包含菜单、项目Logo区、功能按钮区、曲线展示区、数据显示区
大家通过这个程序理解一下利用tkinter一些组件的使用方法
'''
from tkinter.constants import NORMAL

# encoding:utf-8
import numpy as np
import cv2
import re
import pickle
#from PIL import Image, ImageFilter,ImageDraw, ImageFont, ImageEnhance
from matplotlib import pyplot as plt
import tkinter as tk
from tkinter import ttk 
import tkinter.filedialog as file
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg#导入在tkinter 内嵌入的画布子窗口
import tkinter.messagebox as mes
from PIL import Image, ImageTk
#from tkinter import scrolledtext as st
import os
import time

# GUI 初始化
win = tk.Tk() #建立主窗口
win.title('GUI框架演示程序')#窗口标题
win.geometry('1200x700')#窗口宽X高尺寸
win.resizable(width=True, height=True)#设定窗口尺寸可变
#logo 窗口尺寸
ww = 500
wh = 400
#相片窗口尺寸
WW=450
WH=400
CourseName=["高数","英语","编程","导论","政治"]
GI=None#全局图片'高数，英语，编程，导论，政治
WhiteSpace=np.ones((400,450,3), dtype=int)*255#空白照片
def callback():
    print("被调用了")
    return

def LoadImage():
    global GI
    path=os.getcwd()
    filename = file.askopenfilename(title='打开文件名字', initialdir=path,
                                    filetypes=[('jpg文件', '*.jpg'), ('png文件', '.png')])
    if len(filename) == 0:
        return False
    I1 = cv2.imread(filename)
    I1 = cv2.resize(I1, (WW, WH))
    GI = cv2.cvtColor(I1, cv2.COLOR_BGR2RGB)
    fig.clear()
    ax = fig.add_subplot(1, 1, 1, position=[0, 0, 1, 1])
    ax.imshow(GI)
    draw_set.draw()
    OutputFrame.update()
    return True

#装入人脸检测器
faceCascade = cv2.CascadeClassifier('Cascades\haarcascade_frontalface_default.xml')
def FaceTrack():
    cap = cv2.VideoCapture(0)
    cap.open(0, cv2.CAP_DSHOW)
    while True:
        ret, img = cap.read()
        cv2.waitKey(5)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(20, 20))
        if len(faces) != 0:
            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                cv2.putText(img,"Face",(x,y),cv2.FONT_HERSHEY_SIMPLEX,2,(0,255,0),3)
        cv2.imshow('video-Esc-Quit', img)
        k = cv2.waitKey(50) & 0xff
        if k == 27:  # press 'ESC' to quit
            break
    cap.release()
    cv2.destroyWindow('video-Esc-Quit')
    return
#检查当前学号是否已存在学生列表中，是返回True
def CheckStuId(StuId):
    global StuData
    Find = False
    for i in range(len(StuData)):
        stu1 = StuData[i].strip()
        stu2 = re.split('[ ,，]+', stu1)
        if StuId == stu2[0]:
            Find = True
            break
    return Find
#添加一条学生信息记录
def AddStu():
    global StuData
    new_item=DataStr1.get()
    print(new_item)
    if new_item=='':
        return
    stu1 = new_item.strip()
    stu2 = re.split('[ ,，]+', stu1)
    if CheckStuId(stu2[0]):
        mes.showinfo("错误提示信息", "学号已经存在，请修改学号")
        return
    if len(stu2)!=5:
        mes.showinfo("错误提示信息","学生数据格式错误\n 按：“学号，姓名，性别，年龄，班级” 输入")
        return
    StuData.append(new_item)
    StuScore.append(None)
    StuPicture.append(WhiteSpace)
    cbb1['values'] = StuData
    cbb1.set(StuData[-1])
    #print(StuData)
    return
StuData=[]#学生信息-例如：['1001，李明，男，22，智科1班']
StuPicture=[]#学生照片
StuScore=[]#学生分数
def ShowStu():
    return
#删除一条学生信息记录
def DeleteStu():
    global StuData,StuScore,StuPicture
    index=cbb1.current()
    del StuData[index]
    del StuScore[index]
    del StuPicture[index]
    cbb1['values'] = StuData
    return
def FindStu():
    return
#保存现有学生信息，并命名XXXX.dat，如果选择已有文件名,原来的保存的数据将被覆盖
def SaveData():
    global StuData,StuScore,StuPicture
    if len(StuData) ==0:
        return
    filepath = os.getcwd()
    filename = file.asksaveasfilename(title='保存文件名字', initialdir=filepath, filetypes=[('保存文件', '*.dat')])
    if len(filename) == 0:
        return
    with open(filename,'wb') as fp:
        pickle.dump(StuData, fp)
        pickle.dump(StuScore, fp)
        pickle.dump(StuPicture, fp)
    return
#装入现有文件名为XXXX.dat的学生数据信息，并初始化窗口的学生信息列表
def LoadData():
    global StuData, StuScore, StuPicture
    path = os.getcwd()
    filename = file.askopenfilename(title='打开文件名字', initialdir=path,
                                    filetypes=[('dat文件', '*.dat')])
    if len(filename) == 0:
        return
    #filename= 'myfile.dat'
    with open(filename,'rb') as fp:
        StuData = pickle.load(fp)
        StuScore = pickle.load(fp)
        StuPicture = pickle.load(fp)
    cbb1['values']=StuData
    cbb1.set(StuData[0])
    return
    # path=os.getcwd()
    # filename = file.askopenfilename(title='打开文件名字', StuDatadir=path,
    #                                 filetypes=[('dat文件', '*.dat')])
    # if len(filename) == 0:
    #     return
    # with open(filename,'rb') as fp:
    #     global StuData
    #     StuData=pickle.load(fp)
def AddScore():
    global StuData, StuScore
    stuinf = cbb1_str.get()
    if stuinf == '':
        mes.showinfo("错误提示信息", "请先选择学生然后在添加")
        return
    #stuinf=stuinf.strip()
    #stulst=re.split('[ ,，]+', stuinf)
    ScoreStr = DataStr2.get()
    slst1 = ScoreStr.strip()
    slst2 = re.split('[ ,，]+', slst1)
    if len(slst2) != len(CourseName):
        mes.showinfo("错误提示信息", "成绩数据格式错误\n 按：“xx，xx，xx，xx，xx” 输入")
    for i in range(len(slst2)):
        if not slst2[i].isdigit():
            mes.showinfo("错误提示信息", "成绩数据含有非数值")
            return
    ind=cbb1.current()
    StuScore[ind]=slst2.copy()
    ShowScore(ind)
    print(StuScore[ind])
    return
def ShowScore(index):
    global StuScore
    if StuScore[index] is None:
       cbb2['values'] =""
       cbb2.set("")
       return
    Showlist=CourseName.copy()
    for i in range(len(CourseName)):
        Showlist[i]=Showlist[i]+": "+StuScore[index][i]
    cbb2['values']=Showlist
    cbb2.set(Showlist[0])
    return
def ShowPicture(index):
    global StuPicture
    if StuPicture[index] is None:
       fig.clear()
       print("OK")
       return
    fig.clear()
    ax = fig.add_subplot(1, 1, 1, position=[0, 0, 1, 1])
    ax.imshow(StuPicture[index])
    draw_set.draw()
    OutputFrame.update()
    return
def AddPicture():
    global StuPicture, GI
    stuinf = cbb1_str.get()
    if stuinf == '':
        mes.showinfo("错误提示信息", "请先选择学生然后在添加")
        return
    if LoadImage():
       index = cbb1.current()
       StuPicture[index] = GI.copy()
    return
def on_enter1(event):
    AddStu()
def on_enter2(event):
    AddScore()
# =========菜单区=============
menubar = tk.Menu(win)
# file menu
fmenu = tk.Menu(menubar)#主菜单上加入下级子菜单-文件菜单
fmenu.add_command(label='新建', command=callback)
fmenu.add_command(label='打开', command=callback)
fmenu.add_command(label='保存', command=callback)
fmenu.add_command(label='另存为', command=callback)
#学生子菜单
imenu = tk.Menu(menubar)
imenu.add_command(label='浏览学生信息', command=callback)
imenu.add_command(label='添加学生信息', command=callback)
imenu.add_command(label='删除学生信息', command=callback)
imenu.add_command(label='修改学生信息', command=callback)
lmenu = tk.Menu(menubar)
#人脸图像处理子菜单
lmenu.add_command(label='采集10张人脸图像', command=callback)
lmenu.add_command(label='进行人脸识别训练', command=callback)
lmenu.add_command(label='人脸跟踪与识别', command=callback)
lmenu.add_command(label='人脸跟踪与识别', command=callback)
# =============
menubar.add_cascade(label="文件操作", menu=fmenu)
menubar.add_cascade(label="学生信息管理", menu=imenu)
menubar.add_cascade(label="学生人脸识别", menu=lmenu)
win.config(menu=menubar)

# tkinter窗口的布局
# 设置“田”字型4个布局框架Frame 区
# InputFrame：logo图片显示，识别结果显示
# OutputFrame：曲线输出，文本输出
# butFrame：按钮区用于放置各种功能按钮，用组件Button做执行选择，Radiobutton做排它选择
# DataFrame：用于显示各种数据，一般用组件 Entry输出数据, 组件Label命名（贴标签）

InputFrame = tk.Frame(win, height=300, width=600)
OutputFrame = tk.Frame(win, height=300, width=600)
ButFrame = tk.Frame(win, height=300, width=600)
DataFrame = tk.Frame(win, height=300, width=600)
#设定四个框架的网格的行列，“田”字型，是两行两列，行：0~1，列是0~1
InputFrame.grid(row=0, column=0)
OutputFrame.grid(row=0, column=1)
ButFrame.grid(row=1, column=0)
DataFrame.grid(row=1, column=1, sticky=tk.N)
# InputFrame框架，首行放 一个文字标签 “查询结果：" 和一个输出框查询内容 Entry
# 第二行是logo 图片窗口，跨两列
def cbb2_selected(event):
    return
Lab4 = tk.Label(InputFrame, text='查询结果:', font=('Arial', 12), width=20, height=1)
Lab4.grid(row=0, column=0, padx=10, pady=20)
cbb2_str = tk.StringVar()
cbb2 = ttk.Combobox(InputFrame, width=25, textvariable=cbb2_str, state='readonly')
cbb2['values'] =[]
cbb2.grid(row=0,column=1)
cbb2.bind('<<ComboboxSelected>>', cbb2_selected)



logo_path = 'logo.png'
original_image = Image.open(logo_path)
resized_image = original_image.resize((400, 350), Image.Resampling.LANCZOS)  # 设置宽=200, 高=150
LogoImage = ImageTk.PhotoImage(resized_image)
Lab5 = tk.Label(InputFrame, image=LogoImage)
Lab5.grid(row=1, column=0, columnspan=2, padx=40)
# OutputFrame 首行放 一个文字提示标签 “学生信息"和组合框用于显示学生信息列表
# 第二行是一个显示图形图像的画布窗口
#组合框响应函数
def cbb1_selected(event):
    stu=cbb1_str.get()
    stu1=stu.strip()
    stu2=re.split('[ ,，]+',stu1)#
    index=cbb1.current()
    ShowScore(index)
    ShowPicture(index)
    #print(stu2)
    #print(cbb1.current())
#建立一个组合框
cbb1_str = tk.StringVar()
cbb1 = ttk.Combobox(OutputFrame, width=30, textvariable=cbb1_str, state='readonly')
StuData=[]#学生信息-例如：['1001，李明，男，22，智科1班']
StuPicture=[]#学生照片
StuScore=[]#学生分数
cbb1['values'] =StuData
cbb1.grid(row=0,column=1)
cbb1.bind('<<ComboboxSelected>>', cbb1_selected)

Lab5 = tk.Label(OutputFrame, text='学生信息列表', font=('Arial', 14), width=10, height=1)
Lab5.grid(row=0, column=0, pady=20)
fig = plt.Figure(figsize=(4.5, 4), dpi=100)  # 设置空画布窗口，figsize为大小（英寸），dpi为分辨率
draw_set = FigureCanvasTkAgg(fig, master=OutputFrame)  # 将空画布设置在tkinter的输出容器OutputFrame上
ax = fig.add_subplot(1, 1, 1,position=[0, 0, 1, 1])  # 在plt窗口设置坐标系ax
draw_set.get_tk_widget().grid(row=1, column=0,columnspan=2)
#font = {'family': 'Times New Roman', 'weight': 'normal', 'size': 16, }  # 设置字体的字典
#ax.set_xlabel('X-value', font)  # x轴名称并附带字体
#ax.set_ylabel('Y-value', font)  # y轴名称并附带字体

# ButtonFrame 第1行是是10个单选无线按钮
Target = [('0', 0), ('1', 1), ('2', 2), ('3', 3), ('4', 4), ('5', 5), ('6', 6), ('7', 7), ('8', 8), ('9', 9)]
TargetV = tk.IntVar()
Target_startx = 50
Target_starty = 20
#为简化，用一个循环画出10个单选按钮，注意它们公用一个响应函数SetTarget
for txt, num in Target:
    rbut = tk.Radiobutton(ButFrame, text=txt, value=num, font=('Arial', 12), width=3, height=1, variable=TargetV)
    rbut.place(x=Target_startx + num * 50, y=Target_starty)
#第二行就是所有功能按钮放置区，这里有9个，具体功能如下
but1 = tk.Button(ButFrame, text='添加学生', font=('Arial', 12), width=10, height=1, command=AddStu)
but2 = tk.Button(ButFrame, text='显示学生', font=('Arial', 12), width=10, height=1, command=ShowStu)
but3 = tk.Button(ButFrame, text='查找学生', font=('Arial', 12), width=10, height=1, command=FindStu)
but4 = tk.Button(ButFrame, text='删除学生', font=('Arial', 12), width=10, height=1, command=DeleteStu)
but5 = tk.Button(ButFrame, text='人脸跟踪', font=('Arial', 12), width=10, height=1, command=FaceTrack)
but6 = tk.Button(ButFrame, text='数据存盘', font=('Arial', 12), width=10, height=1, command=SaveData)
but7 = tk.Button(ButFrame, text='装入数据', font=('Arial', 12), width=10, height=1, command=LoadData)
but8 = tk.Button(ButFrame, text='添加成绩', font=('Arial', 12), width=10, height=1, command=AddScore)
but9 = tk.Button(ButFrame, text='添加照片', font=('Arial', 12), width=10, height=1, command=AddPicture)
#下面是按钮放置的位置
but1.place(x=50, y=80)
but2.place(x=250, y=80)
but3.place(x=450, y=80)
but4.place(x=50, y=130)
but5.place(x=250, y=130)
but6.place(x=450, y=130)
but7.place(x=50, y=180)
but8.place(x=250, y=180)
but9.place(x=450, y=180)
# DataFrame 数据输出框，主要放置输出的数据和它们的标签
DataStr1 = tk.StringVar()#对应的输入数据1
DataStr2 = tk.StringVar()#对应的输入数据2
DataStr3 = tk.StringVar()#对应的计算结果
Lab1 = tk.Label(DataFrame, text='输入学生信息:', font=('Arial', 12), width=15, height=1)
Lab1.grid(row=1, column=0,pady=0)
Lab11 = tk.Label(DataFrame, text='学号，姓名，性别，年龄，班级      ', font=('Arial', 12), width=30, height=1)
Lab11.grid(row=0, column=1,pady=20)
entry1 = tk.Entry(DataFrame, font=('Arial', 12), width=30, textvariable=DataStr1)
entry1.grid(row=1, column=1,pady=0)
entry1.bind("<Return>", on_enter1)
Lab22 = tk.Label(DataFrame, text='高数，英语，编程，导论，政治      ', font=('Arial', 12), width=30, height=1)
Lab22.grid(row=2, column=1,pady=20)
Lab2 = tk.Label(DataFrame, text='输入学生成绩:', font=('Arial', 12), width=10, height=1)
Lab2.grid(row=3, column=0,pady=0)
entry2 = tk.Entry(DataFrame, font=('Arial', 12), width=30, textvariable=DataStr2)
entry2.grid(row=3, column=1,pady=0)
entry2.bind("<Return>", on_enter2)
#Lab3 = tk.Label(DataFrame, text='其它数据:', font=('Arial', 12), width=10, height=1)
#Lab3.grid(row=5, column=0,pady=10)
#entry3 = tk.Entry(DataFrame, font=('Arial', 12), width=30, textvariable=DataStr3)
#entry3.grid(row=5, column=1,pady=10)
#建立主循环，准备接收窗口组件消息并响应
win.mainloop()
